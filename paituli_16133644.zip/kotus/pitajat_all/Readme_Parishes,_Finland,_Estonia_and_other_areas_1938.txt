Pitäjät, Suomi, Viro, ym rajaalueet / Parishes, Finland, Estonia and other areas 1938
Kotimaisten kielten keskus / Institute for the Languages of Finland
Mittakaava / scale: 1:1 000 000
Koordinaattijärjestelmä / coordinate system: ETRS-TM35FIN
Aineiston kuvaus / Dataset description: http://urn.fi/urn:nbn:fi:csc-kata00001000000000000203